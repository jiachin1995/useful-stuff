# Setup Ansible Environment

### Step 1. Run & Attach to ansible controller
devops\ansible> docker-compose up -d
devops\ansible> docker attach <image_id>

### Step 2. Generate ssh keys
```
# run in ansible controller
/usr/svc>  ssh-keygen -q -t ed25519 -N "" -f /usr/svc/secrets/ssh_client_key
/usr/svc>  cp ./secrets/ssh_client_key ~/.ssh/ssh_client_key
/usr/svc>  chmod  400 ~/.ssh/ssh_client_key

# copy to remote machine (default pw is 'brtsys')
/usr/svc>  ssh-copy-id -p 2222 -i /usr/svc/secrets/ssh_client_key brtsys@host.docker.internal
```

### Step 3. Install python on remote pc
/usr/svc/> ansible-playbook -i inventory.yml playbooks/install_python.yml -vvvv


### Step 4. Install simple webserver
/usr/svc/> ansible-playbook -i inventory.yml playbooks/setup_webserver.yml

# on docker host
open browser > go to http://localhost

### Step 5. Modifying webserver index.html
```
# run on docker host (pw is brtsys)
ssh brtsys@localhost -p 2222

# modify index.html in remote machine
openssh-server/> cd /var/www/html/
/var/www/html> sudo nano index.html 
```

# on docker host
open browser > go to http://localhost (notice that the website has changed)

### Step 6. Doing config management
```
# do dry run (notice that a 'diff' has appeared)
/usr/svc/> ansible-playbook -i inventory.yml playbooks/setup_webserver.yml --check --diff

```
# decision point. Either revert or update playbook

### Generate ssl certs (How to manage files on ansible controller & remote machines)
/usr/svc/> ansible-playbook -i inventory.yml playbooks/generate_ssl_certs.yml

```
# on remote machine (notice that new certs are generated)
/usr/svc/> cd /usr/svc/cert
/usr/svc/cert/> cat mydomain.com.crt

# on ansible controller (notice that files are copied back to ansible controller)
/usr/svc/> cd /usr/svc/secrets/test_pc/
/usr/svc/secrets/test_pc/> cat mydomain.com.crt
```