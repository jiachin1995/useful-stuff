# Define the path to your local JSON file and the URL of the online JSON
$localFilePath = "./ip_list.json"
$onlineUrl = "https://api.fastly.com/public-ip-list"

# 1. Retrieve the local JSON content and convert to a PowerShell object
try {
    $localJson = Get-Content -Path $localFilePath -Raw | ConvertFrom-Json
} catch {
    Write-Error "Error reading local file: $_. Ensure the file path is correct."
    exit
}

# 2. Retrieve the online JSON content and convert to a PowerShell object
try {
    # Use Invoke-RestMethod for automatic JSON conversion
    $onlineJson = Invoke-RestMethod -Uri $onlineUrl
} catch {
    Write-Error "Error retrieving online JSON: $_. Ensure the URL is correct and the network is available."
    exit
}

# 3. Compare the two PowerShell objects
# Compare-Object highlights differences.
# Use the -Property parameter to compare specific properties or omit it for a full comparison.
# The -IncludeEqual parameter can be added to see items that match (optional).
$diff1 = Compare-Object -ReferenceObject $localJson.addresses -DifferenceObject $onlineJson.addresses
$diff2 = Compare-Object -ReferenceObject $localJson.ipv6_addresses -DifferenceObject $onlineJson.ipv6_addresses

# 4. Output the results
if ($diff1 -or $diff2) {
    Write-Host "Differences found between the local and online JSON objects:"
    # SideIndicator legend:
    # => indicates the property is only in the online (difference) object
    # <= indicates the property is only in the local (reference) object
    $diff1 | Format-Table
    Write-Host "____________________"
    $diff2 | Format-Table
} else {
    Write-Host "The local and online JSON objects are identical (based on default comparison)."
}
