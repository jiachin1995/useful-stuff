from aws_srp import AWSSRP, long_to_hex
import requests

# Refer to https://github.com/capless/warrant/blob/master/warrant/aws_srp.py


class AuthenticationFailed (Exception):
    pass

USERNAME = input("Input Username: ")
PASSWORD = input("Input Password: ")
POOL_ID = "ap-southeast-1_FHRAH01zF"
CLIENT_ID = "3qqmktk4pvmlo3puahvv5k80rd"

aws = AWSSRP(username=USERNAME, password=PASSWORD, pool_id=POOL_ID,
             client_id=CLIENT_ID)

srp_A = long_to_hex(aws.large_a_value)

print(f"SRP_A is : {srp_A} \n")

url = 'https://cognito-idp.ap-southeast-1.amazonaws.com/'
headers = {
    'X-Amz-Target': 'AWSCognitoIdentityProviderService.InitiateAuth', 
    "Content-Type":"application/x-amz-json-1.1"
}
body = {
    "AuthFlow": "USER_SRP_AUTH",
    "ClientId": CLIENT_ID,
    "AuthParameters": {
        "USERNAME": USERNAME,
        "SRP_A": srp_A
    }
}

resp1 = requests.post(url, headers = headers, json = body).json()
print("1st response")
print(resp1)

# srp_s = input("Input s: ")
# SECRET_BLK = input("Input SECRET_BLK: ")
# srp_B = input("Input srp_B: ")


# challenge_parameters = {
#     "SALT": srp_s,
#     "SECRET_BLOCK": SECRET_BLK,
#     "SRP_B": srp_B,
#     "USERNAME": USERNAME,
#     "USER_ID_FOR_SRP": USERNAME
# }

challenge_response = aws.process_challenge(resp1["ChallengeParameters"])
# print("PASSWORD_CLAIM_SIGNATURE: " + response["PASSWORD_CLAIM_SIGNATURE"])
# print("PASSWORD_CLAIM_SECRET_BLOCK: " + response["PASSWORD_CLAIM_SECRET_BLOCK"])
# print("TIMESTAMP: " + response["TIMESTAMP"])




url = 'https://cognito-idp.ap-southeast-1.amazonaws.com/'
headers = {
    'X-Amz-Target': 'AWSCognitoIdentityProviderService.RespondToAuthChallenge', 
    "Content-Type":"application/x-amz-json-1.1"
}
body = {
    "ChallengeName": "PASSWORD_VERIFIER",
    "ChallengeResponses": challenge_response,
    "ClientId": "3qqmktk4pvmlo3puahvv5k80rd"
}
print("challenge response")
print(body)

resp2 = requests.post(url, headers = headers, json = body).json()
print("2nd response")
print(resp2)
print()
print("Access token: "+resp2["AuthenticationResult"]["AccessToken"])